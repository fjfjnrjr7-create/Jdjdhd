package com.example.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

// --- Entities ---

@Entity(tableName = "ayahs", primaryKeys = ["surahNumber", "numberInSurah"])
data class AyahEntity(
    val surahNumber: Int,
    val numberInSurah: Int,
    val text: String,
    val translation: String,
    val juz: Int,
    val page: Int
)

@Entity(tableName = "bookmarks")
data class BookmarkEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val surahNumber: Int,
    val numberInSurah: Int,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val surahNumber: Int,
    val numberInSurah: Int,
    val noteText: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "progress")
data class ProgressEntity(
    @PrimaryKey val surahNumber: Int,
    val lastReadAyah: Int,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "memorization", primaryKeys = ["surahNumber", "numberInSurah"])
data class MemorizationEntity(
    val surahNumber: Int,
    val numberInSurah: Int,
    val isMemorized: Boolean = false,
    val repeatCount: Int = 0,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "daily_goals")
data class DailyGoalEntity(
    @PrimaryKey val date: String, // YYYY-MM-DD
    val versesRead: Int = 0,
    val targetVerses: Int = 10,
    val isCompleted: Boolean = false
)

// --- DAOs ---

@Dao
interface AyahDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAyahs(ayahs: List<AyahEntity>)

    @Query("SELECT * FROM ayahs WHERE surahNumber = :surahNumber ORDER BY numberInSurah ASC")
    fun getAyahsForSurah(surahNumber: Int): Flow<List<AyahEntity>>

    @Query("SELECT * FROM ayahs WHERE juz = :juz ORDER BY surahNumber ASC, numberInSurah ASC")
    fun getAyahsForJuz(juz: Int): Flow<List<AyahEntity>>

    @Query("SELECT * FROM ayahs WHERE page = :page ORDER BY surahNumber ASC, numberInSurah ASC")
    fun getAyahsForPage(page: Int): Flow<List<AyahEntity>>

    @Query("SELECT COUNT(*) FROM ayahs WHERE surahNumber = :surahNumber")
    suspend fun countAyahsForSurah(surahNumber: Int): Int

    @Query("SELECT COUNT(*) FROM ayahs")
    suspend fun countAllAyahs(): Int

    @Query("SELECT * FROM ayahs WHERE text LIKE '%' || :query || '%' OR translation LIKE '%' || :query || '%' ORDER BY surahNumber ASC, numberInSurah ASC")
    fun searchAyahs(query: String): Flow<List<AyahEntity>>
}

@Dao
interface BookmarkDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBookmark(bookmark: BookmarkEntity)

    @Query("DELETE FROM bookmarks WHERE surahNumber = :surahNumber AND numberInSurah = :numberInSurah")
    suspend fun deleteBookmark(surahNumber: Int, numberInSurah: Int)

    @Query("SELECT * FROM bookmarks ORDER BY timestamp DESC")
    fun getAllBookmarks(): Flow<List<BookmarkEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM bookmarks WHERE surahNumber = :surahNumber AND numberInSurah = :numberInSurah)")
    fun isBookmarked(surahNumber: Int, numberInSurah: Int): Flow<Boolean>
}

@Dao
interface NoteDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: NoteEntity)

    @Query("DELETE FROM notes WHERE id = :id")
    suspend fun deleteNote(id: Int)

    @Query("SELECT * FROM notes WHERE surahNumber = :surahNumber ORDER BY numberInSurah ASC")
    fun getNotesForSurah(surahNumber: Int): Flow<List<NoteEntity>>

    @Query("SELECT * FROM notes ORDER BY timestamp DESC")
    fun getAllNotes(): Flow<List<NoteEntity>>
}

@Dao
interface ProgressDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveProgress(progress: ProgressEntity)

    @Query("SELECT * FROM progress WHERE surahNumber = :surahNumber")
    fun getProgressForSurah(surahNumber: Int): Flow<ProgressEntity?>

    @Query("SELECT * FROM progress ORDER BY timestamp DESC")
    fun getAllProgress(): Flow<List<ProgressEntity>>
}

@Dao
interface MemorizationDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveMemorization(memo: MemorizationEntity)

    @Query("SELECT * FROM memorization WHERE surahNumber = :surahNumber")
    fun getMemorizationForSurah(surahNumber: Int): Flow<List<MemorizationEntity>>

    @Query("UPDATE memorization SET isMemorized = :isMemorized WHERE surahNumber = :surahNumber AND numberInSurah = :numberInSurah")
    suspend fun updateMemorizationStatus(surahNumber: Int, numberInSurah: Int, isMemorized: Boolean)

    @Query("UPDATE memorization SET repeatCount = :repeatCount WHERE surahNumber = :surahNumber AND numberInSurah = :numberInSurah")
    suspend fun updateRepeatCount(surahNumber: Int, numberInSurah: Int, repeatCount: Int)
    
    @Query("SELECT * FROM memorization WHERE isMemorized = 1")
    fun getMemorizedAyahs(): Flow<List<MemorizationEntity>>
}

@Dao
interface DailyGoalDao {
    @Query("SELECT * FROM daily_goals WHERE date = :date")
    fun getGoalForDate(date: String): Flow<DailyGoalEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGoal(goal: DailyGoalEntity)

    @Query("UPDATE daily_goals SET versesRead = versesRead + :count, isCompleted = (versesRead + :count) >= targetVerses WHERE date = :date")
    suspend fun incrementVersesRead(date: String, count: Int)

    @Query("SELECT * FROM daily_goals ORDER BY date DESC")
    fun getAllGoals(): Flow<List<DailyGoalEntity>>
}

// --- Database ---

@Database(
    entities = [
        AyahEntity::class,
        BookmarkEntity::class,
        NoteEntity::class,
        ProgressEntity::class,
        MemorizationEntity::class,
        DailyGoalEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class QuranDatabase : RoomDatabase() {
    abstract fun ayahDao(): AyahDao
    abstract fun bookmarkDao(): BookmarkDao
    abstract fun noteDao(): NoteDao
    abstract fun progressDao(): ProgressDao
    abstract fun memorizationDao(): MemorizationDao
    abstract fun dailyGoalDao(): DailyGoalDao

    companion object {
        @Volatile
        private var INSTANCE: QuranDatabase? = null

        fun getDatabase(context: Context): QuranDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    QuranDatabase::class.java,
                    "quran_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
