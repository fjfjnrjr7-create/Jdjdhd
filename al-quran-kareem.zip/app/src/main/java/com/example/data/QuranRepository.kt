package com.example.data

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class QuranRepository(private val db: QuranDatabase) {

    private val ayahDao = db.ayahDao()
    private val bookmarkDao = db.bookmarkDao()
    private val noteDao = db.noteDao()
    private val progressDao = db.progressDao()
    private val memorizationDao = db.memorizationDao()
    private val dailyGoalDao = db.dailyGoalDao()

    private val client = OkHttpClient()

    // --- Core Read Functions ---

    fun getAyahsForSurah(surahNumber: Int): Flow<List<AyahEntity>> {
        return ayahDao.getAyahsForSurah(surahNumber)
    }

    fun getAyahsForJuz(juz: Int): Flow<List<AyahEntity>> {
        return ayahDao.getAyahsForJuz(juz)
    }

    fun getAyahsForPage(page: Int): Flow<List<AyahEntity>> {
        return ayahDao.getAyahsForPage(page)
    }

    suspend fun countAyahsForSurah(surahNumber: Int): Int {
        return ayahDao.countAyahsForSurah(surahNumber)
    }

    fun searchAyahs(query: String): Flow<List<AyahEntity>> {
        return ayahDao.searchAyahs(query)
    }

    // --- Bookmarks ---

    fun getAllBookmarks(): Flow<List<BookmarkEntity>> = bookmarkDao.getAllBookmarks()

    suspend fun addBookmark(surahNumber: Int, numberInSurah: Int) {
        bookmarkDao.insertBookmark(BookmarkEntity(surahNumber = surahNumber, numberInSurah = numberInSurah))
    }

    suspend fun removeBookmark(surahNumber: Int, numberInSurah: Int) {
        bookmarkDao.deleteBookmark(surahNumber, numberInSurah)
    }

    fun isBookmarked(surahNumber: Int, numberInSurah: Int): Flow<Boolean> {
        return bookmarkDao.isBookmarked(surahNumber, numberInSurah)
    }

    // --- Notes ---

    fun getNotesForSurah(surahNumber: Int): Flow<List<NoteEntity>> = noteDao.getNotesForSurah(surahNumber)

    fun getAllNotes(): Flow<List<NoteEntity>> = noteDao.getAllNotes()

    suspend fun addNote(surahNumber: Int, numberInSurah: Int, noteText: String) {
        noteDao.insertNote(NoteEntity(surahNumber = surahNumber, numberInSurah = numberInSurah, noteText = noteText))
    }

    suspend fun deleteNote(id: Int) {
        noteDao.deleteNote(id)
    }

    // --- Reading Progress ---

    fun getProgressForSurah(surahNumber: Int): Flow<ProgressEntity?> = progressDao.getProgressForSurah(surahNumber)

    fun getAllProgress(): Flow<List<ProgressEntity>> = progressDao.getAllProgress()

    suspend fun saveProgress(surahNumber: Int, lastReadAyah: Int) {
        progressDao.saveProgress(ProgressEntity(surahNumber = surahNumber, lastReadAyah = lastReadAyah))
        // Increment daily goal counter by 1
        incrementDailyGoal()
    }

    // --- Memorization Progress ---

    fun getMemorizationForSurah(surahNumber: Int): Flow<List<MemorizationEntity>> = memorizationDao.getMemorizationForSurah(surahNumber)

    fun getMemorizedAyahs(): Flow<List<MemorizationEntity>> = memorizationDao.getMemorizedAyahs()

    suspend fun toggleMemorized(surahNumber: Int, numberInSurah: Int, isMemorized: Boolean) {
        // Check if record exists, if not insert first
        val currentList = memorizationDao.getMemorizationForSurah(surahNumber).first()
        val exists = currentList.any { it.numberInSurah == numberInSurah }
        if (!exists) {
            memorizationDao.saveMemorization(
                MemorizationEntity(
                    surahNumber = surahNumber,
                    numberInSurah = numberInSurah,
                    isMemorized = isMemorized
                )
            )
        } else {
            memorizationDao.updateMemorizationStatus(surahNumber, numberInSurah, isMemorized)
        }
    }

    suspend fun updateRepeatCount(surahNumber: Int, numberInSurah: Int, count: Int) {
        val currentList = memorizationDao.getMemorizationForSurah(surahNumber).first()
        val exists = currentList.any { it.numberInSurah == numberInSurah }
        if (!exists) {
            memorizationDao.saveMemorization(
                MemorizationEntity(
                    surahNumber = surahNumber,
                    numberInSurah = numberInSurah,
                    repeatCount = count
                )
            )
        } else {
            memorizationDao.updateRepeatCount(surahNumber, numberInSurah, count)
        }
    }

    // --- Daily Goals & Streaks ---

    private fun getCurrentDateString(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return sdf.format(Date())
    }

    fun getGoalForToday(): Flow<DailyGoalEntity?> {
        val date = getCurrentDateString()
        return dailyGoalDao.getGoalForDate(date)
    }

    fun getAllGoals(): Flow<List<DailyGoalEntity>> = dailyGoalDao.getAllGoals()

    suspend fun initTodayGoal(targetVerses: Int = 10) {
        val date = getCurrentDateString()
        val current = dailyGoalDao.getGoalForDate(date).first()
        if (current == null) {
            dailyGoalDao.insertGoal(DailyGoalEntity(date = date, targetVerses = targetVerses))
        }
    }

    private suspend fun incrementDailyGoal() {
        val date = getCurrentDateString()
        initTodayGoal()
        dailyGoalDao.incrementVersesRead(date, 1)
    }

    // --- Prepopulate popular Surahs offline ---

    suspend fun prepopulateOfflineSurahs() {
        withContext(Dispatchers.IO) {
            if (ayahDao.countAllAyahs() == 0) {
                // Populate Surah 1 (Al-Fatihah)
                val fatihah = listOf(
                    AyahEntity(1, 1, "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ", "In the name of Allah, the Entirely Merciful, the Especially Merciful.", 1, 1),
                    AyahEntity(1, 2, "الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ", "[All] praise is [due] to Allah, Lord of the worlds -", 1, 1),
                    AyahEntity(1, 3, "الرَّحْمَٰنِ الرَّحِيمِ", "The Entirely Merciful, the Especially Merciful,", 1, 1),
                    AyahEntity(1, 4, "مَالِكِ يَوْمِ الدِّينِ", "Sovereign of the Day of Recompense.", 1, 1),
                    AyahEntity(1, 5, "إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ", "It is You we worship and You we ask for help.", 1, 1),
                    AyahEntity(1, 6, "اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ", "Guide us to the straight path -", 1, 1),
                    AyahEntity(1, 7, "صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ", "The path of those upon whom You have bestowed favor, not of those who have evoked [Your] anger or of those who are astray.", 1, 1)
                )
                ayahDao.insertAyahs(fatihah)

                // Populate Surah 112 (Al-Ikhlas)
                val ikhlas = listOf(
                    AyahEntity(112, 1, "قُلْ هُوَ اللَّهُ أَحَدٌ", "Say, \"He is Allah, [who is] One,", 30, 604),
                    AyahEntity(112, 2, "اللَّهُ الصَّمَدُ", "Allah, the Eternal Refuge.", 30, 604),
                    AyahEntity(112, 3, "لَمْ يَلِدْ وَلَمْ يُولَدْ", "He neither begets nor is born,", 30, 604),
                    AyahEntity(112, 4, "وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ", "Nor is there to Him any equivalent.\"", 30, 604)
                )
                ayahDao.insertAyahs(ikhlas)

                // Populate Surah 113 (Al-Falaq)
                val falaq = listOf(
                    AyahEntity(113, 1, "قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ", "Say, \"I seek refuge in the Lord of daybreak", 30, 604),
                    AyahEntity(113, 2, "من شَرِّ مَا خَلَقَ", "From the evil of what He created", 30, 604),
                    AyahEntity(113, 3, "وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ", "And from the evil of darkness when it settles", 30, 604),
                    AyahEntity(113, 4, "وَمِن شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ", "And from the evil of the blowers in knots", 30, 604),
                    AyahEntity(113, 5, "وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ", "And from the evil of an envier when he envies.\"", 30, 604)
                )
                ayahDao.insertAyahs(falaq)

                // Populate Surah 114 (An-Nas)
                val nas = listOf(
                    AyahEntity(114, 1, "قُلْ أَعُوذُ بِرَبِّ النَّاسِ", "Say, \"I seek refuge in the Lord of mankind,", 30, 604),
                    AyahEntity(114, 2, "مَلِكِ النَّاسِ", "The Sovereign of mankind,", 30, 604),
                    AyahEntity(114, 3, "إِلَٰهِ النَّاسِ", "The God of mankind,", 30, 604),
                    AyahEntity(114, 4, "مِن شَرِّ الْوَسْوَاسِ الْخَنَّاسِ", "From the evil of the retreating whisperer -", 30, 604),
                    AyahEntity(114, 5, "الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ", "Who whispers [evil] into the breasts of mankind -", 30, 604),
                    AyahEntity(114, 6, "مِنَ الْجِنَّةِ وَالنَّاسِ", "From among the jinn and mankind.\"", 30, 604)
                )
                ayahDao.insertAyahs(nas)
            }
        }
    }

    // --- Dynamic Surah Fetcher & Cache ---

    suspend fun downloadSurah(surahNumber: Int): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            // Fetch Uthmani script text
            val arabicRequest = Request.Builder()
                .url("https://api.alquran.cloud/v1/surah/$surahNumber/quran-uthmani")
                .build()

            val englishRequest = Request.Builder()
                .url("https://api.alquran.cloud/v1/surah/$surahNumber/en.sahih")
                .build()

            val arabicResponse = client.newCall(arabicRequest).execute()
            if (!arabicResponse.isSuccessful) return@withContext Result.failure(IOException("Failed to download Arabic text for Surah $surahNumber: ${arabicResponse.message}"))

            val englishResponse = client.newCall(englishRequest).execute()
            if (!englishResponse.isSuccessful) return@withContext Result.failure(IOException("Failed to download English text for Surah $surahNumber: ${englishResponse.message}"))

            val arabicJsonStr = arabicResponse.body?.string() ?: return@withContext Result.failure(Exception("Empty Arabic response body"))
            val englishJsonStr = englishResponse.body?.string() ?: return@withContext Result.failure(Exception("Empty English response body"))

            val arabicObj = JSONObject(arabicJsonStr)
            val englishObj = JSONObject(englishJsonStr)

            if (arabicObj.getInt("code") != 200 || englishObj.getInt("code") != 200) {
                return@withContext Result.failure(Exception("API returned non-200 code"))
            }

            val arabicAyahs = arabicObj.getJSONObject("data").getJSONArray("ayahs")
            val englishAyahs = englishObj.getJSONObject("data").getJSONArray("ayahs")

            val entities = mutableListOf<AyahEntity>()
            for (i in 0 until arabicAyahs.length()) {
                val aObj = arabicAyahs.getJSONObject(i)
                val eObj = englishAyahs.getJSONObject(i)

                val numInSurah = aObj.getInt("numberInSurah")
                val text = aObj.getString("text")
                val translation = eObj.getString("text")
                val juz = aObj.getInt("juz")
                val page = aObj.getInt("page")

                entities.add(
                    AyahEntity(
                        surahNumber = surahNumber,
                        numberInSurah = numInSurah,
                        text = text,
                        translation = translation,
                        juz = juz,
                        page = page
                    )
                )
            }

            ayahDao.insertAyahs(entities)
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("QuranRepository", "Error downloading Surah $surahNumber", e)
            Result.failure(e)
        }
    }
}
