package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = GoldPrimary,
    secondary = LightTeal,
    tertiary = GoldSecondary,
    background = DarkBackground,
    surface = CardBackground,
    onPrimary = EmeraldDark,
    onSecondary = TextIvory,
    onTertiary = EmeraldDark,
    onBackground = TextIvory,
    onSurface = TextIvory,
    surfaceVariant = EmeraldDark,
    onSurfaceVariant = TextMuted
)

private val LightColorScheme = lightColorScheme(
    primary = LightPrimary,
    secondary = LightSecondary,
    tertiary = GoldPrimary,
    background = LightBackground,
    surface = LightCardBackground,
    onPrimary = TextIvory,
    onSecondary = TextIvory,
    onTertiary = TextIvory,
    onBackground = LightTextDark,
    onSurface = LightTextDark,
    surfaceVariant = LightBackground,
    onSurfaceVariant = LightTextMuted
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Force premium dark mode by default for Al-Quran Kareem
    dynamicColor: Boolean = false, // Use our handcrafted beautiful palette instead of arbitrary system dynamic colors
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
