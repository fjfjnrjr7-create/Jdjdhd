package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light/Dark Theme Color Tokens for Al-Quran Kareem App
// Deep Emerald Teal and Golden Sand theme for a sacred, serene aesthetic

val GoldPrimary = Color(0xFFD4AF37) // Golden Sand Accent
val GoldSecondary = Color(0xFFE5C158)
val DeepTeal = Color(0xFF0D3B36) // Deep Teal
val LightTeal = Color(0xFF2E6B65)
val EmeraldDark = Color(0xFF071C19) // Obsidian Teal / Obsidian Emerald
val DarkBackground = Color(0xFF051210) // Ultra Deep Emerald Dark
val CardBackground = Color(0xFF0A2622) // Elevated surface Teal
val TextIvory = Color(0xFFF4F1EA) // Ivory for high contrast text
val TextMuted = Color(0xFF8B9E9B) // Muted sage green text
val HighlightYellow = Color(0x33FFE082) // Subtle translucent gold highlight for playing verse
val AlertRed = Color(0xFFE57373)
val AlertRedDark = Color(0xFFD32F2F)

// Light theme alternatives (for accessibility, if toggled)
val LightPrimary = Color(0xFF0D3B36)
val LightSecondary = Color(0xFF2E6B65)
val LightBackground = Color(0xFFF9F7F2)
val LightCardBackground = Color(0xFFFFFFFF)
val LightTextDark = Color(0xFF1F292E)
val LightTextMuted = Color(0xFF6B7280)
