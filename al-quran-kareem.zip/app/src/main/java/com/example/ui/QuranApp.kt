package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.audio.Reciter
import com.example.data.AyahEntity
import com.example.data.QuranMetadata
import com.example.data.SurahMetadata
import com.example.ui.theme.*
import kotlinx.coroutines.launch

sealed interface Screen {
    object Index : Screen
    data class Reader(val type: ReaderType, val id: Int, val highlightAyah: Int? = null) : Screen
    object BookmarksAndNotes : Screen
    object StatsAndMemorization : Screen
}

enum class ReaderType {
    SURAH, JUZ, PAGE
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuranApp(viewModel: QuranViewModel) {
    var currentScreen by remember { mutableStateOf<Screen>(Screen.Index) }
    val scope = rememberCoroutineScope()

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = EmeraldDark,
                contentColor = TextMuted,
                windowInsets = WindowInsets.navigationBars
            ) {
                NavigationBarItem(
                    selected = currentScreen is Screen.Index,
                    onClick = { currentScreen = Screen.Index },
                    icon = { Icon(Icons.Filled.Menu, contentDescription = "Home Index") },
                    label = { Text("Index") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = GoldPrimary,
                        selectedTextColor = GoldPrimary,
                        indicatorColor = CardBackground
                    ),
                    modifier = Modifier.testTag("nav_index")
                )
                NavigationBarItem(
                    selected = currentScreen is Screen.BookmarksAndNotes,
                    onClick = { currentScreen = Screen.BookmarksAndNotes },
                    icon = { Icon(Icons.Filled.Bookmark, contentDescription = "Bookmarks") },
                    label = { Text("Bookmarks") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = GoldPrimary,
                        selectedTextColor = GoldPrimary,
                        indicatorColor = CardBackground
                    ),
                    modifier = Modifier.testTag("nav_bookmarks")
                )
                NavigationBarItem(
                    selected = currentScreen is Screen.StatsAndMemorization,
                    onClick = { currentScreen = Screen.StatsAndMemorization },
                    icon = { Icon(Icons.Filled.Star, contentDescription = "Memorize") },
                    label = { Text("Memorize") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = GoldPrimary,
                        selectedTextColor = GoldPrimary,
                        indicatorColor = CardBackground
                    ),
                    modifier = Modifier.testTag("nav_stats")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(DarkBackground)
        ) {
            AnimatedContent(
                targetState = currentScreen,
                transitionSpec = {
                    fadeIn() togetherWith fadeOut()
                },
                label = "ScreenTransition"
            ) { screen ->
                when (screen) {
                    is Screen.Index -> {
                        IndexScreen(
                            viewModel = viewModel,
                            onNavigateToReader = { type, id ->
                                currentScreen = Screen.Reader(type, id)
                            }
                        )
                    }
                    is Screen.Reader -> {
                        ReaderScreen(
                            viewModel = viewModel,
                            type = screen.type,
                            id = screen.id,
                            initialHighlightAyah = screen.highlightAyah,
                            onBack = { currentScreen = Screen.Index }
                        )
                    }
                    is Screen.BookmarksAndNotes -> {
                        BookmarksAndNotesScreen(
                            viewModel = viewModel,
                            onNavigateToVerse = { surah, ayah ->
                                currentScreen = Screen.Reader(ReaderType.SURAH, surah, ayah)
                            }
                        )
                    }
                    is Screen.StatsAndMemorization -> {
                        StatsAndMemorizationScreen(
                            viewModel = viewModel,
                            onNavigateToVerse = { surah, ayah ->
                                currentScreen = Screen.Reader(ReaderType.SURAH, surah, ayah)
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun IndexScreen(
    viewModel: QuranViewModel,
    onNavigateToReader: (ReaderType, Int) -> Unit
) {
    val surahs by viewModel.filteredSurahs.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val todayGoal by viewModel.todayGoal.collectAsStateWithLifecycle()
    val streak by viewModel.currentStreak.collectAsStateWithLifecycle()
    val allProgress by viewModel.allProgress.collectAsStateWithLifecycle()

    var activeTab by remember { mutableStateOf(0) } // 0 = Surah, 1 = Juz, 2 = Page

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("index_list"),
        contentPadding = PaddingValues(bottom = 16.dp)
    ) {
        // Hero Header
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_quran_hero),
                    contentDescription = "Al-Quran Kareem",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, DarkBackground),
                                startY = 100f
                            )
                        )
                )
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(20.dp)
                ) {
                    Text(
                        text = "Al-Quran Kareem",
                        style = MaterialTheme.typography.headlineLarge.copy(
                            color = GoldPrimary,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    )
                    Text(
                        text = "The Light that Guides and Inspires",
                        style = MaterialTheme.typography.bodyMedium.copy(color = TextIvory.copy(alpha = 0.8f))
                    )
                }
            }
        }

        // Daily Progress Card & Streak
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                colors = CardDefaults.cardColors(containerColor = CardBackground),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Daily Reading Goal",
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = GoldPrimary,
                                fontWeight = FontWeight.SemiBold
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        todayGoal?.let { goal ->
                            val progress = if (goal.targetVerses > 0) goal.versesRead.toFloat() / goal.targetVerses else 0f
                            Text(
                                text = "${goal.versesRead} / ${goal.targetVerses} Verses Completed Today",
                                style = MaterialTheme.typography.bodyMedium.copy(color = TextIvory)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            LinearProgressIndicator(
                                progress = { progress.coerceIn(0f, 1f) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(CircleShape),
                                color = GoldSecondary,
                                trackColor = EmeraldDark
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .background(EmeraldDark, CircleShape)
                                .border(1.dp, GoldPrimary, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "🔥",
                                fontSize = 24.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "$streak Days",
                            style = MaterialTheme.typography.labelLarge.copy(
                                color = GoldPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }
            }
        }

        // Quick Resume Card (if any reading progress exists)
        if (allProgress.isNotEmpty()) {
            val lastProgress = allProgress.first()
            val meta = QuranMetadata.surahs.find { it.number == lastProgress.surahNumber }
            if (meta != null) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        colors = CardDefaults.cardColors(containerColor = EmeraldDark),
                        shape = RoundedCornerShape(12.dp),
                        onClick = { onNavigateToReader(ReaderType.SURAH, lastProgress.surahNumber) }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Filled.History,
                                contentDescription = "History",
                                tint = GoldPrimary,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.width(16.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Continue Reading",
                                    style = MaterialTheme.typography.labelMedium.copy(color = TextMuted)
                                )
                                Text(
                                    text = "${meta.englishName} (Ayah ${lastProgress.lastReadAyah})",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        color = TextIvory,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }
                            Icon(
                                Icons.Filled.PlayArrow,
                                contentDescription = "Resume",
                                tint = GoldPrimary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                }
            }
        }

        // Search & Custom Tab Selectors
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                TextField(
                    value = searchQuery,
                    onValueChange = { viewModel.updateSearchQuery(it) },
                    placeholder = { Text("Search Surah name or number...") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "Search", tint = TextMuted) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_bar"),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = CardBackground,
                        unfocusedContainerColor = CardBackground,
                        focusedTextColor = TextIvory,
                        unfocusedTextColor = TextIvory,
                        focusedIndicatorColor = GoldPrimary,
                        unfocusedIndicatorColor = Color.Transparent
                    ),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(16.dp))

                TabRow(
                    selectedTabIndex = activeTab,
                    containerColor = Color.Transparent,
                    contentColor = GoldPrimary
                ) {
                    Tab(
                        selected = activeTab == 0,
                        onClick = { activeTab = 0 },
                        text = { Text("Surahs", fontWeight = if (activeTab == 0) FontWeight.Bold else FontWeight.Normal) }
                    )
                    Tab(
                        selected = activeTab == 1,
                        onClick = { activeTab = 1 },
                        text = { Text("Juz' (Parts)", fontWeight = if (activeTab == 1) FontWeight.Bold else FontWeight.Normal) }
                    )
                    Tab(
                        selected = activeTab == 2,
                        onClick = { activeTab = 2 },
                        text = { Text("Pages", fontWeight = if (activeTab == 2) FontWeight.Bold else FontWeight.Normal) }
                    )
                }
            }
        }

        // Tab Contents
        when (activeTab) {
            0 -> {
                if (surahs.isEmpty()) {
                    item {
                        EmptyState(text = "No Surahs match your search criteria.")
                    }
                } else {
                    items(surahs, key = { it.number }) { surah ->
                        SurahListItem(
                            surah = surah,
                            onClick = { onNavigateToReader(ReaderType.SURAH, surah.number) }
                        )
                    }
                }
            }
            1 -> {
                items(QuranMetadata.juzNames.entries.toList(), key = { it.key }) { entry ->
                    JuzListItem(
                        juzNumber = entry.key,
                        juzRange = entry.value,
                        onClick = { onNavigateToReader(ReaderType.JUZ, entry.key) }
                    )
                }
            }
            2 -> {
                // Show pages list (1 to 604)
                items((1..604).toList().chunked(4)) { pageRow ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        for (page in pageRow) {
                            Card(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(60.dp),
                                colors = CardDefaults.cardColors(containerColor = CardBackground),
                                shape = RoundedCornerShape(8.dp),
                                onClick = { onNavigateToReader(ReaderType.PAGE, page) }
                            ) {
                                Box(
                                    modifier = Modifier.fillMaxSize(),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "Page $page",
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            color = TextIvory,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SurahListItem(
    surah: SurahMetadata,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .clickable { onClick() }
            .testTag("surah_item_${surah.number}"),
        colors = CardDefaults.cardColors(containerColor = CardBackground),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Surah Number inside stylized gold octagon
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .background(EmeraldDark, CircleShape)
                    .border(1.dp, GoldPrimary, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = surah.number.toString(),
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = GoldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            // English details
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = surah.englishName,
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = TextIvory,
                        fontWeight = FontWeight.Bold
                    )
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = surah.revelationType,
                        style = MaterialTheme.typography.labelSmall.copy(color = TextMuted)
                    )
                    Box(
                        modifier = Modifier
                            .size(3.dp)
                            .background(TextMuted, CircleShape)
                    )
                    Text(
                        text = "${surah.numberOfAyahs} Ayat",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextMuted)
                    )
                }
            }

            // Arabic text + download status
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = surah.name,
                    style = MaterialTheme.typography.titleLarge.copy(
                        color = GoldPrimary,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Right
                    ),
                    modifier = Modifier.padding(bottom = 2.dp)
                )
                Text(
                    text = surah.englishNameTranslation,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = TextMuted,
                        textAlign = TextAlign.Right
                    )
                )
            }
        }
    }
}

@Composable
fun JuzListItem(
    juzNumber: Int,
    juzRange: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = CardBackground),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .background(EmeraldDark, CircleShape)
                    .border(1.dp, GoldPrimary, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = juzNumber.toString(),
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = GoldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column {
                Text(
                    text = "Juz' $juzNumber",
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = TextIvory,
                        fontWeight = FontWeight.Bold
                    )
                )
                Text(
                    text = juzRange,
                    style = MaterialTheme.typography.bodySmall.copy(color = TextMuted)
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReaderScreen(
    viewModel: QuranViewModel,
    type: ReaderType,
    id: Int,
    initialHighlightAyah: Int? = null,
    onBack: () -> Unit
) {
    val readerState by viewModel.readerState.collectAsStateWithLifecycle()
    val downloadProgress by viewModel.downloadProgress.collectAsStateWithLifecycle()
    val bookmarks by viewModel.bookmarks.collectAsStateWithLifecycle()
    val memorizedList by viewModel.memorizedAyahs.collectAsStateWithLifecycle()

    val currentPlayingSurah by viewModel.audioPlayer.currentPlayingSurah.collectAsStateWithLifecycle()
    val currentPlayingAyah by viewModel.audioPlayer.currentPlayingAyah.collectAsStateWithLifecycle()
    val isPlaying by viewModel.audioPlayer.isPlaying.collectAsStateWithLifecycle()
    val selectedReciter by viewModel.audioPlayer.selectedReciter.collectAsStateWithLifecycle()

    var memorizationModeEnabled by remember { mutableStateOf(false) }
    var showDialogForAyahNotes by remember { mutableStateOf<AyahEntity?>(null) }
    var currentNoteInput by remember { mutableStateOf("") }
    var showReciterMenu by remember { mutableStateOf(false) }
    var showRepeatRangeDialog by remember { mutableStateOf(false) }

    // Memorization settings
    var hiddenVersesState = remember { mutableStateMapOf<Int, Boolean>() } // Maps numberInSurah -> isHidden

    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    LaunchedEffect(type, id) {
        when (type) {
            ReaderType.SURAH -> viewModel.loadSurah(id)
            ReaderType.JUZ -> viewModel.loadJuz(id)
            ReaderType.PAGE -> viewModel.loadPage(id)
        }
    }

    // Scroll to initial highlight if specified
    LaunchedEffect(readerState) {
        if (readerState is SurahUiState.Success && initialHighlightAyah != null) {
            val index = (readerState as SurahUiState.Success).ayahs.indexOfFirst { it.numberInSurah == initialHighlightAyah }
            if (index >= 0) {
                scope.launch {
                    listState.scrollToItem(index)
                }
            }
        }
    }

    // Scroll automatically to match playing verse if active
    LaunchedEffect(currentPlayingAyah) {
        val s = currentPlayingSurah
        val a = currentPlayingAyah
        if (s != null && a != null && readerState is SurahUiState.Success) {
            val index = (readerState as SurahUiState.Success).ayahs.indexOfFirst { it.surahNumber == s && it.numberInSurah == a }
            if (index >= 0) {
                scope.launch {
                    listState.animateScrollToItem(index)
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    val titleText = when (type) {
                        ReaderType.SURAH -> {
                            val meta = QuranMetadata.surahs.find { it.number == id }
                            "${meta?.englishName ?: "Surah"} (${meta?.name ?: ""})"
                        }
                        ReaderType.JUZ -> "Juz' $id"
                        ReaderType.PAGE -> "Page $id"
                    }
                    Text(
                        text = titleText,
                        style = MaterialTheme.typography.titleLarge.copy(
                            color = GoldPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    )
                },
                navigationIcon = {
                    IconButton(onClick = {
                        viewModel.stopAudio()
                        onBack()
                    }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = GoldPrimary)
                    }
                },
                actions = {
                    // Memorization mode toggle
                    IconButton(onClick = { memorizationModeEnabled = !memorizationModeEnabled }) {
                        Icon(
                            imageVector = if (memorizationModeEnabled) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                            contentDescription = "Memorization Focus",
                            tint = if (memorizationModeEnabled) GoldPrimary else TextMuted
                        )
                    }

                    // Reciter selector
                    Box {
                        IconButton(onClick = { showReciterMenu = true }) {
                            Icon(Icons.Filled.Settings, contentDescription = "Settings", tint = GoldPrimary)
                        }
                        DropdownMenu(
                            expanded = showReciterMenu,
                            onDismissRequest = { showReciterMenu = false },
                            modifier = Modifier.background(CardBackground)
                        ) {
                            Reciter.values().forEach { reciter ->
                                DropdownMenuItem(
                                    text = { Text(reciter.displayName, color = if (selectedReciter == reciter) GoldPrimary else TextIvory) },
                                    onClick = {
                                        viewModel.audioPlayer.selectReciter(reciter)
                                        showReciterMenu = false
                                    }
                                )
                            }
                        }
                    }

                    if (type == ReaderType.SURAH) {
                        // Repeat range button for memorization loop
                        IconButton(onClick = { showRepeatRangeDialog = true }) {
                            Icon(Icons.Filled.Refresh, contentDescription = "Repeat Loop", tint = GoldPrimary)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = EmeraldDark)
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(DarkBackground)
        ) {
            when (val state = readerState) {
                is SurahUiState.Idle -> {}
                is SurahUiState.Loading -> {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator(color = GoldPrimary)
                        Spacer(modifier = Modifier.height(16.dp))
                        downloadProgress?.let { progress ->
                            Text(
                                text = "Initializing offline database... ${(progress * 100).toInt()}%",
                                style = MaterialTheme.typography.bodyMedium.copy(color = TextIvory)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            LinearProgressIndicator(
                                progress = { progress },
                                modifier = Modifier
                                    .width(200.dp)
                                    .clip(CircleShape),
                                color = GoldPrimary,
                                trackColor = EmeraldDark
                            )
                        } ?: Text(
                            text = "Loading sacred text...",
                            style = MaterialTheme.typography.bodyMedium.copy(color = TextMuted)
                        )
                    }
                }
                is SurahUiState.Error -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            Icons.Filled.CloudDownload,
                            contentDescription = "Error",
                            tint = AlertRed,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = state.message,
                            style = MaterialTheme.typography.bodyLarge.copy(color = TextIvory, textAlign = TextAlign.Center)
                        )
                        Spacer(modifier = Modifier.height(24.dp))
                        if (type == ReaderType.SURAH) {
                            Button(
                                onClick = { viewModel.triggerSurahDownload(id) },
                                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary)
                            ) {
                                Text("Download Surah", color = EmeraldDark, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
                is SurahUiState.Success -> {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp)
                    ) {
                        // Bismillah banner
                        if (type == ReaderType.SURAH && id != 9 && id != 1) {
                            item {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 16.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ",
                                        fontSize = 28.sp,
                                        fontFamily = FontFamily.Serif,
                                        fontWeight = FontWeight.Bold,
                                        color = GoldPrimary,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }

                        items(state.ayahs, key = { "${it.surahNumber}_${it.numberInSurah}" }) { ayah ->
                            val isHighlighted = currentPlayingSurah == ayah.surahNumber && currentPlayingAyah == ayah.numberInSurah
                            val isBookmarked = bookmarks.any { it.surahNumber == ayah.surahNumber && it.numberInSurah == ayah.numberInSurah }
                            val isMemorized = memorizedList.any { it.surahNumber == ayah.surahNumber && it.numberInSurah == ayah.numberInSurah }

                            val isHidden = memorizationModeEnabled && hiddenVersesState.getOrPut(ayah.numberInSurah) { true }

                            AyahCard(
                                ayah = ayah,
                                isHighlighted = isHighlighted,
                                isBookmarked = isBookmarked,
                                isMemorized = isMemorized,
                                isHidden = isHidden,
                                onToggleHide = {
                                    hiddenVersesState[ayah.numberInSurah] = !isHidden
                                },
                                onPlay = {
                                    viewModel.playAyahAudio(ayah.surahNumber, ayah.numberInSurah)
                                },
                                onToggleBookmark = {
                                    viewModel.toggleBookmark(ayah.surahNumber, ayah.numberInSurah)
                                },
                                onWriteNote = {
                                    showDialogForAyahNotes = ayah
                                    currentNoteInput = ""
                                },
                                onToggleMemorize = {
                                    viewModel.toggleMemorized(ayah.surahNumber, ayah.numberInSurah, !isMemorized)
                                }
                            )
                        }
                    }
                }
            }

            // Bottom Player Floating Controls Bar
            if (isPlaying && currentPlayingSurah != null && currentPlayingAyah != null) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .padding(16.dp)
                ) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = EmeraldDark),
                        shape = RoundedCornerShape(16.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                val meta = QuranMetadata.surahs.find { it.number == currentPlayingSurah }
                                Text(
                                    text = "Reciting: ${meta?.englishName ?: "Surah"}",
                                    style = MaterialTheme.typography.titleMedium.copy(color = GoldPrimary, fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "Ayah $currentPlayingAyah (${selectedReciter.displayName})",
                                    style = MaterialTheme.typography.bodySmall.copy(color = TextIvory.copy(alpha = 0.8f))
                                )
                            }
                            IconButton(onClick = { viewModel.pauseAudio() }) {
                                Icon(
                                    imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                    contentDescription = "Pause",
                                    tint = GoldPrimary,
                                    modifier = Modifier.size(32.dp)
                                )
                            }
                            IconButton(onClick = { viewModel.stopAudio() }) {
                                Icon(
                                    Icons.Filled.Stop,
                                    contentDescription = "Stop",
                                    tint = AlertRed,
                                    modifier = Modifier.size(32.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Study Note Write Dialog
    showDialogForAyahNotes?.let { ayah ->
        Dialog(onDismissRequest = { showDialogForAyahNotes = null }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardBackground),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = "Study Journal Notes",
                        style = MaterialTheme.typography.titleLarge.copy(color = GoldPrimary, fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Ayah ${ayah.numberInSurah} of Surah ${QuranMetadata.surahs.find { it.number == ayah.surahNumber }?.englishName}",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextMuted)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    OutlinedTextField(
                        value = currentNoteInput,
                        onValueChange = { currentNoteInput = it },
                        placeholder = { Text("Write down reflections, lessons, or memory anchors for this verse...", color = TextMuted) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextIvory,
                            unfocusedTextColor = TextIvory,
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = TextMuted
                        )
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { showDialogForAyahNotes = null }) {
                            Text("Cancel", color = TextMuted)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (currentNoteInput.isNotBlank()) {
                                    viewModel.addNote(ayah.surahNumber, ayah.numberInSurah, currentNoteInput)
                                }
                                showDialogForAyahNotes = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary)
                        ) {
                            Text("Save Reflection", color = EmeraldDark, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // Repeat Range Dialog for memorization loop
    if (showRepeatRangeDialog) {
        var startInput by remember { mutableStateOf("1") }
        var endInput by remember { mutableStateOf("5") }
        var repeatsInput by remember { mutableStateOf("3") }

        Dialog(onDismissRequest = { showRepeatRangeDialog = false }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = CardBackground),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = "Memorization Repeat Loop",
                        style = MaterialTheme.typography.titleLarge.copy(color = GoldPrimary, fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Repeat a range of verses repeatedly for solid retention.",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextMuted)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = startInput,
                            onValueChange = { startInput = it },
                            label = { Text("Start Ayah") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = TextIvory,
                                unfocusedTextColor = TextIvory,
                                focusedBorderColor = GoldPrimary,
                                unfocusedBorderColor = TextMuted
                            )
                        )
                        OutlinedTextField(
                            value = endInput,
                            onValueChange = { endInput = it },
                            label = { Text("End Ayah") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = TextIvory,
                                unfocusedTextColor = TextIvory,
                                focusedBorderColor = GoldPrimary,
                                unfocusedBorderColor = TextMuted
                            )
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = repeatsInput,
                        onValueChange = { repeatsInput = it },
                        label = { Text("Repeat Count (e.g. 5x)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextIvory,
                            unfocusedTextColor = TextIvory,
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = TextMuted
                        )
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { showRepeatRangeDialog = false }) {
                            Text("Cancel", color = TextMuted)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                val start = startInput.toIntOrNull() ?: 1
                                val end = endInput.toIntOrNull() ?: 5
                                val reps = repeatsInput.toIntOrNull() ?: 3
                                viewModel.playRangeAudio(id, start, end, reps)
                                showRepeatRangeDialog = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary)
                        ) {
                            Text("Start Loop", color = EmeraldDark, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AyahCard(
    ayah: AyahEntity,
    isHighlighted: Boolean,
    isBookmarked: Boolean,
    isMemorized: Boolean,
    isHidden: Boolean,
    onToggleHide: () -> Unit,
    onPlay: () -> Unit,
    onToggleBookmark: () -> Unit,
    onWriteNote: () -> Unit,
    onToggleMemorize: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .border(
                width = if (isHighlighted) 2.dp else 1.dp,
                color = if (isHighlighted) GoldPrimary else Color.Transparent,
                shape = RoundedCornerShape(12.dp)
            )
            .testTag("ayah_${ayah.surahNumber}_${ayah.numberInSurah}"),
        colors = CardDefaults.cardColors(
            containerColor = if (isHighlighted) HighlightYellow else CardBackground
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Verse Number header bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Surah ${ayah.surahNumber} : Ayah ${ayah.numberInSurah}",
                    style = MaterialTheme.typography.labelLarge.copy(
                        color = GoldPrimary,
                        fontWeight = FontWeight.Bold
                    )
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (isMemorized) {
                        Icon(
                            Icons.Filled.CheckCircle,
                            contentDescription = "Memorized",
                            tint = GoldSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Text(
                        text = "Page ${ayah.page} (Juz' ${ayah.juz})",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextMuted)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Arabic text (Uthmani) RTL
            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.CenterEnd
            ) {
                if (isHidden) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(60.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(EmeraldDark)
                            .clickable { onToggleHide() },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Verse Hidden for Memorization. Tap to reveal.",
                            style = MaterialTheme.typography.bodyMedium.copy(color = GoldPrimary, fontWeight = FontWeight.Bold)
                        )
                    }
                } else {
                    Text(
                        text = ayah.text,
                        fontSize = 26.sp,
                        fontFamily = FontFamily.Serif,
                        fontWeight = FontWeight.Bold,
                        color = TextIvory,
                        textAlign = TextAlign.Right,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onToggleHide() },
                        style = MaterialTheme.typography.bodyLarge.copy(
                            textDirection = TextDirection.Rtl,
                            lineHeight = 44.sp
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Translation text LTR
            if (!isHidden) {
                Text(
                    text = ayah.translation,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = TextMuted,
                        lineHeight = 22.sp
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Action row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { onPlay() }) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = "Play Audio", tint = GoldPrimary)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(onClick = { onToggleBookmark() }) {
                        Icon(
                            imageVector = if (isBookmarked) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                            contentDescription = "Bookmark",
                            tint = if (isBookmarked) GoldPrimary else TextMuted
                        )
                    }
                    IconButton(onClick = { onWriteNote() }) {
                        Icon(Icons.Filled.Edit, contentDescription = "Study Reflection Notes", tint = GoldPrimary)
                    }
                    IconButton(onClick = { onToggleMemorize() }) {
                        Icon(
                            imageVector = if (isMemorized) Icons.Filled.CheckCircle else Icons.Filled.Star,
                            contentDescription = "Mark Memorized",
                            tint = if (isMemorized) GoldSecondary else TextMuted
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun BookmarksAndNotesScreen(
    viewModel: QuranViewModel,
    onNavigateToVerse: (Int, Int) -> Unit
) {
    val bookmarks by viewModel.bookmarks.collectAsStateWithLifecycle()
    val notes by viewModel.allNotes.collectAsStateWithLifecycle()

    var activeTab by remember { mutableStateOf(0) } // 0 = Bookmarks, 1 = Study Reflections

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "My Quran Study Journal",
            style = MaterialTheme.typography.headlineMedium.copy(color = GoldPrimary, fontWeight = FontWeight.Bold)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Track your favorite verses and daily reflections",
            style = MaterialTheme.typography.bodySmall.copy(color = TextMuted)
        )

        Spacer(modifier = Modifier.height(16.dp))

        TabRow(
            selectedTabIndex = activeTab,
            containerColor = Color.Transparent,
            contentColor = GoldPrimary
        ) {
            Tab(
                selected = activeTab == 0,
                onClick = { activeTab = 0 },
                text = { Text("Bookmarks (${bookmarks.size})") }
            )
            Tab(
                selected = activeTab == 1,
                onClick = { activeTab = 1 },
                text = { Text("Study Reflections (${notes.size})") }
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (activeTab == 0) {
            if (bookmarks.isEmpty()) {
                EmptyState(text = "You haven't added any bookmarks yet. Tap the bookmark icon while reading to save verses.")
            } else {
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(bookmarks, key = { it.id }) { bookmark ->
                        val meta = QuranMetadata.surahs.find { it.number == bookmark.surahNumber }
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp),
                            colors = CardDefaults.cardColors(containerColor = CardBackground),
                            shape = RoundedCornerShape(12.dp),
                            onClick = { onNavigateToVerse(bookmark.surahNumber, bookmark.numberInSurah) }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Filled.Bookmark, contentDescription = "Saved", tint = GoldPrimary)
                                Spacer(modifier = Modifier.width(16.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${meta?.englishName ?: "Surah"} - Ayah ${bookmark.numberInSurah}",
                                        style = MaterialTheme.typography.titleMedium.copy(color = TextIvory, fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = meta?.englishNameTranslation ?: "",
                                        style = MaterialTheme.typography.bodySmall.copy(color = TextMuted)
                                    )
                                }
                                IconButton(onClick = { viewModel.toggleBookmark(bookmark.surahNumber, bookmark.numberInSurah) }) {
                                    Icon(Icons.Filled.Delete, contentDescription = "Remove", tint = AlertRed)
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (notes.isEmpty()) {
                EmptyState(text = "Your journal is empty. Tap the note edit icon on any verse while reading to record study reflections.")
            } else {
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(notes, key = { it.id }) { note ->
                        val meta = QuranMetadata.surahs.find { it.number == note.surahNumber }
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            colors = CardDefaults.cardColors(containerColor = CardBackground),
                            shape = RoundedCornerShape(12.dp),
                            onClick = { onNavigateToVerse(note.surahNumber, note.numberInSurah) }
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "${meta?.englishName} (Ayah ${note.numberInSurah})",
                                        style = MaterialTheme.typography.titleMedium.copy(color = GoldPrimary, fontWeight = FontWeight.Bold)
                                    )
                                    IconButton(onClick = { viewModel.deleteNote(note.id) }) {
                                        Icon(Icons.Filled.Delete, contentDescription = "Delete", tint = AlertRed, modifier = Modifier.size(20.dp))
                                    }
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = note.noteText,
                                    style = MaterialTheme.typography.bodyMedium.copy(color = TextIvory, lineHeight = 20.sp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatsAndMemorizationScreen(
    viewModel: QuranViewModel,
    onNavigateToVerse: (Int, Int) -> Unit
) {
    val memorizedList by viewModel.memorizedAyahs.collectAsStateWithLifecycle()
    val allGoals by viewModel.allGoalsHistory.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "Hifz & Reading Progress",
            style = MaterialTheme.typography.headlineMedium.copy(color = GoldPrimary, fontWeight = FontWeight.Bold)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Track your memorization milestones and reading history",
            style = MaterialTheme.typography.bodySmall.copy(color = TextMuted)
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Total memorized stat card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CardBackground),
            shape = RoundedCornerShape(16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Total Memorized Ayat",
                        style = MaterialTheme.typography.titleMedium.copy(color = TextMuted)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${memorizedList.size} Verses",
                        style = MaterialTheme.typography.headlineLarge.copy(color = GoldPrimary, fontWeight = FontWeight.Bold)
                    )
                }
                Box(
                    modifier = Modifier
                        .size(60.dp)
                        .background(EmeraldDark, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.Star, contentDescription = "Star", tint = GoldPrimary, modifier = Modifier.size(32.dp))
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "Memorized Verses Registry",
            style = MaterialTheme.typography.titleLarge.copy(color = GoldPrimary, fontWeight = FontWeight.Bold)
        )

        Spacer(modifier = Modifier.height(12.dp))

        if (memorizedList.isEmpty()) {
            EmptyState(text = "No verses marked as memorized yet. Use the star icon under verses in the reader to build your memorized list.")
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(memorizedList, key = { "${it.surahNumber}_${it.numberInSurah}" }) { item ->
                    val meta = QuranMetadata.surahs.find { it.number == item.surahNumber }
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        colors = CardDefaults.cardColors(containerColor = CardBackground),
                        shape = RoundedCornerShape(12.dp),
                        onClick = { onNavigateToVerse(item.surahNumber, item.numberInSurah) }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.CheckCircle, contentDescription = "Memorized", tint = GoldSecondary)
                            Spacer(modifier = Modifier.width(16.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${meta?.englishName ?: "Surah"} - Ayah ${item.numberInSurah}",
                                    style = MaterialTheme.typography.titleMedium.copy(color = TextIvory, fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "Reviewed ${item.repeatCount} times",
                                    style = MaterialTheme.typography.bodySmall.copy(color = TextMuted)
                                )
                            }
                            IconButton(onClick = { viewModel.incrementRepeatCount(item.surahNumber, item.numberInSurah) }) {
                                Icon(Icons.Filled.Refresh, contentDescription = "Review Counter Increment", tint = GoldPrimary)
                            }
                            IconButton(onClick = { viewModel.toggleMemorized(item.surahNumber, item.numberInSurah, false) }) {
                                Icon(Icons.Filled.Close, contentDescription = "Unmark", tint = AlertRed)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EmptyState(text: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                Icons.Filled.AutoAwesome,
                contentDescription = "Empty",
                tint = GoldPrimary.copy(alpha = 0.5f),
                modifier = Modifier.size(48.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = text,
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = TextMuted,
                    textAlign = TextAlign.Center,
                    lineHeight = 20.sp
                )
            )
        }
    }
}
