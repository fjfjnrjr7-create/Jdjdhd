package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.QuranAudioPlayer
import com.example.audio.Reciter
import com.example.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

sealed interface SurahUiState {
    object Idle : SurahUiState
    object Loading : SurahUiState
    data class Success(val ayahs: List<AyahEntity>) : SurahUiState
    data class Error(val message: String) : SurahUiState
}

class QuranViewModel(application: Application) : AndroidViewModel(application) {

    private val db = QuranDatabase.getDatabase(application)
    private val repository = QuranRepository(db)
    val audioPlayer = QuranAudioPlayer()

    // --- Search & Index lists ---
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery

    private val _selectedJuzFilter = MutableStateFlow<Int?>(null)
    val selectedJuzFilter: StateFlow<Int?> = _selectedJuzFilter

    private val _selectedRevelationType = MutableStateFlow<String?>(null) // "Meccan" or "Medinan"
    val selectedRevelationType: StateFlow<String?> = _selectedRevelationType

    // Surah list combined with local cache download statuses
    val filteredSurahs = combine(
        _searchQuery,
        _selectedJuzFilter,
        _selectedRevelationType
    ) { query, juz, revType ->
        QuranMetadata.surahs.filter { surah ->
            val matchesQuery = surah.englishName.contains(query, ignoreCase = true) ||
                    surah.englishNameTranslation.contains(query, ignoreCase = true) ||
                    surah.name.contains(query) ||
                    surah.number.toString() == query

            val matchesJuz = juz == null || surah.startJuz == juz
            val matchesRevType = revType == null || surah.revelationType.equals(revType, ignoreCase = true)

            matchesQuery && matchesJuz && matchesRevType
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), QuranMetadata.surahs)

    // --- Reader Screen state ---
    private val _activeSurahNumber = MutableStateFlow<Int?>(null)
    val activeSurahNumber: StateFlow<Int?> = _activeSurahNumber

    private val _readerState = MutableStateFlow<SurahUiState>(SurahUiState.Idle)
    val readerState: StateFlow<SurahUiState> = _readerState

    private val _downloadProgress = MutableStateFlow<Float?>(null) // null = not downloading, otherwise 0f to 1f
    val downloadProgress: StateFlow<Float?> = _downloadProgress

    // --- Bookmarks & Progress Flows ---
    val bookmarks = repository.getAllBookmarks().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allProgress = repository.getAllProgress().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allNotes = repository.getAllNotes().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val memorizedAyahs = repository.getMemorizedAyahs().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Daily Goal & Streak ---
    val todayGoal = repository.getGoalForToday().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
    val allGoalsHistory = repository.getAllGoals().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val currentStreak = allGoalsHistory.map { goals ->
        var streak = 0
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val cal = Calendar.getInstance()
        
        var checkDate = sdf.format(cal.time)
        while (true) {
            val goal = goals.find { it.date == checkDate }
            if (goal != null && goal.isCompleted) {
                streak++
                cal.add(Calendar.DATE, -1)
                checkDate = sdf.format(cal.time)
            } else {
                // Check if they just haven't finished today's goal yet but finished yesterday's
                if (checkDate == sdf.format(Date())) {
                    cal.add(Calendar.DATE, -1)
                    checkDate = sdf.format(cal.time)
                    val yesterdayGoal = goals.find { it.date == checkDate }
                    if (yesterdayGoal != null && yesterdayGoal.isCompleted) {
                        // Keep checking yesterday backwards
                        continue
                    }
                }
                break
            }
        }
        streak
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    init {
        viewModelScope.launch {
            // Prepopulate several Surahs so the user has offline data immediately on first app use!
            repository.prepopulateOfflineSurahs()
            repository.initTodayGoal()
        }
    }

    // --- Search & Filtering Actions ---
    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun filterByJuz(juz: Int?) {
        _selectedJuzFilter.value = juz
    }

    fun filterByRevelation(type: String?) {
        _selectedRevelationType.value = type
    }

    // --- Reader Actions ---
    fun loadSurah(surahNumber: Int) {
        _activeSurahNumber.value = surahNumber
        _readerState.value = SurahUiState.Loading
        _downloadProgress.value = null

        viewModelScope.launch {
            repository.getAyahsForSurah(surahNumber).collect { ayahs ->
                val meta = QuranMetadata.surahs.find { it.number == surahNumber } ?: return@collect
                if (ayahs.size == meta.numberOfAyahs) {
                    _readerState.value = SurahUiState.Success(ayahs)
                } else {
                    // Try to download
                    triggerSurahDownload(surahNumber)
                }
            }
        }
    }

    fun loadJuz(juzNumber: Int) {
        _activeSurahNumber.value = null
        _readerState.value = SurahUiState.Loading
        viewModelScope.launch {
            repository.getAyahsForJuz(juzNumber).collect { ayahs ->
                if (ayahs.isNotEmpty()) {
                    _readerState.value = SurahUiState.Success(ayahs)
                } else {
                    _readerState.value = SurahUiState.Error("Juz $juzNumber data is offline. Please view and download individual Surahs first to populate this Juz.")
                }
            }
        }
    }

    fun loadPage(pageNumber: Int) {
        _activeSurahNumber.value = null
        _readerState.value = SurahUiState.Loading
        viewModelScope.launch {
            repository.getAyahsForPage(pageNumber).collect { ayahs ->
                if (ayahs.isNotEmpty()) {
                    _readerState.value = SurahUiState.Success(ayahs)
                } else {
                    _readerState.value = SurahUiState.Error("Page $pageNumber data is offline. Please view and download individual Surahs first to populate this page.")
                }
            }
        }
    }

    fun triggerSurahDownload(surahNumber: Int) {
        viewModelScope.launch(Dispatchers.Main) {
            _downloadProgress.value = 0.1f
            val result = repository.downloadSurah(surahNumber)
            if (result.isSuccess) {
                _downloadProgress.value = 1.0f
                // Let the collector naturally load from DB
            } else {
                _downloadProgress.value = null
                _readerState.value = SurahUiState.Error(
                    result.exceptionOrNull()?.message ?: "Failed to download Surah. Please check internet connection."
                )
            }
        }
    }

    // --- Bookmarking & Progress Actions ---
    fun toggleBookmark(surahNumber: Int, numberInSurah: Int) {
        viewModelScope.launch {
            val isBookmarkedCurrently = bookmarks.value.any { it.surahNumber == surahNumber && it.numberInSurah == numberInSurah }
            if (isBookmarkedCurrently) {
                repository.removeBookmark(surahNumber, numberInSurah)
            } else {
                repository.addBookmark(surahNumber, numberInSurah)
            }
        }
    }

    fun saveReadingProgress(surahNumber: Int, ayahNumber: Int) {
        viewModelScope.launch {
            repository.saveProgress(surahNumber, ayahNumber)
        }
    }

    // --- Memorization Actions ---
    fun toggleMemorized(surahNumber: Int, numberInSurah: Int, isMemorized: Boolean) {
        viewModelScope.launch {
            repository.toggleMemorized(surahNumber, numberInSurah, isMemorized)
        }
    }

    fun incrementRepeatCount(surahNumber: Int, numberInSurah: Int) {
        viewModelScope.launch {
            val current = repository.getMemorizationForSurah(surahNumber).first().find { it.numberInSurah == numberInSurah }
            val nextCount = (current?.repeatCount ?: 0) + 1
            repository.updateRepeatCount(surahNumber, numberInSurah, nextCount)
        }
    }

    // --- Notes Actions ---
    fun addNote(surahNumber: Int, numberInSurah: Int, text: String) {
        viewModelScope.launch {
            repository.addNote(surahNumber, numberInSurah, text)
        }
    }

    fun deleteNote(id: Int) {
        viewModelScope.launch {
            repository.deleteNote(id)
        }
    }

    // --- Audio Control Pass-Throughs ---
    fun playAyahAudio(surah: Int, ayah: Int) {
        audioPlayer.playAyah(surah, ayah) {
            // Automatically play next ayah if possible
            val activeState = _readerState.value
            if (activeState is SurahUiState.Success) {
                val nextAyah = activeState.ayahs.find { it.numberInSurah == ayah + 1 }
                if (nextAyah != null) {
                    playAyahAudio(surah, nextAyah.numberInSurah)
                    // Auto-save progress
                    saveReadingProgress(surah, nextAyah.numberInSurah)
                }
            }
        }
    }

    fun playRangeAudio(surah: Int, startAyah: Int, endAyah: Int, repeats: Int) {
        audioPlayer.playRange(surah, startAyah, endAyah, repeats) { currentAyah ->
            saveReadingProgress(surah, currentAyah)
        }
    }

    fun pauseAudio() {
        audioPlayer.togglePlayPause()
    }

    fun stopAudio() {
        audioPlayer.stop()
    }

    override fun onCleared() {
        super.onCleared()
        audioPlayer.stop()
    }
}
