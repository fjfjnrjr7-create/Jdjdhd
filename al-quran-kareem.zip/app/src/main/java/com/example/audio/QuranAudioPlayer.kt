package com.example.audio

import android.media.AudioAttributes
import android.media.MediaPlayer
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

enum class Reciter(val displayName: String, val folder: String) {
    ALAFASY("Mishary Rashid Alafasy", "Alafasy_128kbps"),
    AL_HUSARY("Mahmoud Khalil Al-Husary", "Husary_128kbps"),
    ABDUL_BASIT("Abdul Basit Abdul Samad", "Abdul_Basit_Murattal_192kbps")
}

class QuranAudioPlayer {

    private var mediaPlayer: MediaPlayer? = null

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying

    private val _currentPlayingSurah = MutableStateFlow<Int?>(null)
    val currentPlayingSurah: StateFlow<Int?> = _currentPlayingSurah

    private val _currentPlayingAyah = MutableStateFlow<Int?>(null)
    val currentPlayingAyah: StateFlow<Int?> = _currentPlayingAyah

    private val _selectedReciter = MutableStateFlow(Reciter.ALAFASY)
    val selectedReciter: StateFlow<Reciter> = _selectedReciter

    // Memorization/Repeat Settings
    private var repeatCountLeft = 0
    private var isRepeatModeActive = false
    private var rangeStartAyah = -1
    private var rangeEndAyah = -1

    private val coroutineScope = CoroutineScope(Dispatchers.Main)

    fun selectReciter(reciter: Reciter) {
        _selectedReciter.value = reciter
        // If playing, restart with new reciter
        val s = _currentPlayingSurah.value
        val a = _currentPlayingAyah.value
        if (s != null && a != null && _isPlaying.value) {
            playAyah(s, a)
        }
    }

    fun playAyah(surah: Int, ayah: Int, onComplete: (() -> Unit)? = null) {
        stop()

        _currentPlayingSurah.value = surah
        _currentPlayingAyah.value = ayah
        _isPlaying.value = true

        val reciterFolder = _selectedReciter.value.folder
        val surahStr = String.format("%03d", surah)
        val ayahStr = String.format("%03d", ayah)
        val url = "https://everyayah.com/data/$reciterFolder/$surahStr$ayahStr.mp3"

        Log.d("QuranAudioPlayer", "Playing audio: $url")

        mediaPlayer = MediaPlayer().apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .build()
            )
            try {
                setDataSource(url)
                setOnPreparedListener {
                    start()
                }
                setOnCompletionListener {
                    _isPlaying.value = false
                    release()
                    mediaPlayer = null
                    onComplete?.invoke()
                }
                setOnErrorListener { _, what, extra ->
                    Log.e("QuranAudioPlayer", "MediaPlayer Error $what, $extra")
                    _isPlaying.value = false
                    true
                }
                prepareAsync()
            } catch (e: Exception) {
                Log.e("QuranAudioPlayer", "Error starting player", e)
                _isPlaying.value = false
            }
        }
    }

    fun playRange(surah: Int, startAyah: Int, endAyah: Int, repeats: Int, onAyahChanged: (Int) -> Unit) {
        rangeStartAyah = startAyah
        rangeEndAyah = endAyah
        repeatCountLeft = repeats
        isRepeatModeActive = true

        playRangeAyah(surah, startAyah, onAyahChanged)
    }

    private fun playRangeAyah(surah: Int, currentAyah: Int, onAyahChanged: (Int) -> Unit) {
        if (!isRepeatModeActive) return

        onAyahChanged(currentAyah)
        playAyah(surah, currentAyah) {
            if (currentAyah < rangeEndAyah) {
                // Next Ayah in range
                playRangeAyah(surah, currentAyah + 1, onAyahChanged)
            } else {
                // Completed one range iteration
                if (repeatCountLeft > 1) {
                    repeatCountLeft--
                    playRangeAyah(surah, rangeStartAyah, onAyahChanged)
                } else {
                    // All repeats complete
                    isRepeatModeActive = false
                    _currentPlayingSurah.value = null
                    _currentPlayingAyah.value = null
                }
            }
        }
    }

    fun togglePlayPause() {
        mediaPlayer?.let {
            if (it.isPlaying) {
                it.pause()
                _isPlaying.value = false
            } else {
                it.start()
                _isPlaying.value = true
            }
        }
    }

    fun stop() {
        isRepeatModeActive = false
        mediaPlayer?.let {
            if (it.isPlaying) {
                it.stop()
            }
            it.release()
        }
        mediaPlayer = null
        _isPlaying.value = false
    }
}
